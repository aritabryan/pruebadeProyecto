package proyecto_bryanarita_eduardovaldez;

import javax.swing.*;

public class Proyecto_BryanArita_EduardoValdez {

    static JFrame f = new JFrame();

    public static void main(String[] args) {

            JFrame gui=new JFrame();
            gui.setVisible(true);

    }

}
