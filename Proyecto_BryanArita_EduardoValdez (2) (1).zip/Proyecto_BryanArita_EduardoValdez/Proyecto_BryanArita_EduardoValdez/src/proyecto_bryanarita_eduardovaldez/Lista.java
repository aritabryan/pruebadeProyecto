package proyecto_bryanarita_eduardovaldez;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import javax.swing.JOptionPane;

public class Lista {

    static Scanner leer = new Scanner(System.in);
    static Random rand = new Random();

    public void Game() {

        JOptionPane.showMessageDialog(null, "**********ENCUENTRA AL TOPO!**********\nEl topo se esta escondiendo en las casillas, ATRAPALO!\nTienes 5 oportunidades para atraparlo\nIngrese la casilla donde cree que esta el topo");

        int[][] matrices = generartablero(6, 6);

        imprimir(matrices);
        boolean victoria = false;
        int rounds = 0;

        while (victoria == false && rounds < 5) {
            rounds++;
            int filat = rand.nextInt(6);
            int columnat = rand.nextInt(6);
            escondite(matrices, filat, columnat);

            String[] split;
            String dimensiones = JOptionPane.showInputDialog(null, "Ingrese la casilla que quiere marcar[(0,0)-(5,5)]: \n\n Ejemplo: (1,1)");
            split = dimensiones.split(",");

            int fila = Integer.parseInt(split[0]);
            int columna = Integer.parseInt(split[1]);

            casilla(matrices, fila, columna);

            if (fila == filat && columna == columnat) {
                victoria = true;
                JOptionPane.showMessageDialog(null, "HAS ENCONTRADO AL TOPO!");
            } else if (fila != filat || columna != columnat) {

                int[][] matrices2 = round(matrices, fila, columna);

                imprimir2(matrices2);
                matrices = matrices2;
            }

        }
        if (victoria == false) {
            JOptionPane.showMessageDialog(null, "No pudiste encontrar al topo :(\nHAS PERDIDO!");

        }

    }

    public void escondite(int[][] matriz, int filas, int columnas) {
        if (matriz[filas][columnas] == 1) {
            filas = rand.nextInt(6);
            columnas = rand.nextInt(6);
        }

    }

    public void casilla(int[][] matriz, int filas, int columnas) {
        if (matriz[filas][columnas] == 1) {
            String[] split;
            String dimensiones = JOptionPane.showInputDialog(null, "Esta casilla ya no esta disponible\n\nIngrese la casilla que quiere marcar[(0,0)-(5,5)]: \n\n Ejemplo: (1,1)");
            split = dimensiones.split(",");
            filas = Integer.parseInt(split[0]);
            columnas = Integer.parseInt(split[1]);
        }

    }

    public void imprimir(int[][] matriz) {
        String acumulador = "";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (matriz[i][j] == 1) {
                    acumulador += "[" + matriz[i][j] + "]";
                } else {
                    acumulador += "[ ]";
                }

            }
            acumulador += "\n";
        }
        JOptionPane.showMessageDialog(null, "Tablero\n" + acumulador);

        System.out.println();
    }

    public void imprimir2(int[][] matriz) {
        String acumulador = "";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (matriz[i][j] == 1) {
                    acumulador += "[" + matriz[i][j] + "]";
                } else {
                    acumulador += "[ ]";
                }

            }
            acumulador += "\n";
        }
        ArrayList<String> Coordenadas = lista(matriz, 6, 6);

        ArrayList<String> coordenada = Coordenadas;

        JOptionPane.showMessageDialog(null, "Tablero\nCasillas ya marcadas: " + coordenada + "\n" + acumulador);

    }

    public int[][] generartablero(int fila, int columna) {
        int[][] temporal = new int[fila][columna];

        return temporal;
    }

    public ArrayList<String> lista(int[][] matriz, int filas, int columnas) {
        ArrayList<String> Coordenadas = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (matriz[i][j] == 1) {
                    String coordenada = "(" + i + ":" + j + ")";
                    Coordenadas.add(coordenada);
                }
            }
        }

        return Coordenadas;
    }

    public int[][] round(int[][] matriz, int filas, int columnas) {
        int[][] temporal = matriz;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if (i == filas && j == columnas) {
                    matriz[i][j] = 1;
                }
            }

        }
        return temporal;
    }

}
