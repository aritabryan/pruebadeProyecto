/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_bryanarita_eduardovaldez;

import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Recursivo {

    public Scanner duki = new Scanner(System.in);
    public Random rndm = new Random();

    public void Apuestas() {

        int numApuestas = 0;
        int saldo = 250;
        String decision = "s";
        while ("s".equals(decision) || "S".equals(decision)) {

            String cantidad = JOptionPane.showInputDialog(null, "Saldo actual: " + saldo + "\n¿Cuánto desea apostar?");

            int apuesta = Integer.parseInt(cantidad);

            if (apuesta > saldo) {
                JOptionPane.showMessageDialog(null, "Lo siento, no tienes suficiente saldo para realizar esta apuesta.");

            } else {
                int resultado = apostar(apuesta);
                saldo += resultado;
                numApuestas++;
            }
            String decisiones = JOptionPane.showInputDialog(null, "Desea hacer otra apuesta[S/N]?");
            decision = decisiones;

        }

        JOptionPane.showMessageDialog(null, "Gracias por jugar. Hasta la próxima.");

        JOptionPane.showMessageDialog(null, "Resumen de las apuestas:\n\n- Número total de apuestas: " + numApuestas + "\n- Saldo final: " + saldo);
    }

    public int apostar(int apuesta) {
        String num = JOptionPane.showInputDialog(null, "¿Qué número cree que va a ser el siguiente en la secuencia?");

        int numElegido = Integer.parseInt(num);

        int numSiguiente = generarNumeroSiguiente(numElegido);

        if (numSiguiente == numElegido) {
            JOptionPane.showMessageDialog(null, "¡Felicidades! Ha acertado. Le devolvemos su apuesta y gana lo que aposto.");
            return apuesta * 2;

        } else {
            JOptionPane.showMessageDialog(null, "Lo siento, su elección no fue correcta. Le devolvemos su apuesta.");

            return -apuesta;
        }
    }

    public int generarNumeroSiguiente(int numAnterior) {
        int random = rndm.nextInt(10) + 1;
        return (numAnterior * numAnterior) % random;
    }
}
