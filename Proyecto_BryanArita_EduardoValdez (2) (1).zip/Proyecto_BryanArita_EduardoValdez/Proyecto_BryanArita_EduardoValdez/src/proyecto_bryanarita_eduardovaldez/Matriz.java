package proyecto_bryanarita_eduardovaldez;

import java.awt.Color;
import java.util.Random;
import javax.swing.*;
import java.util.Scanner;

public class Matriz {

    public Scanner duki = new Scanner(System.in);
    public Random rndm = new Random();

    public void Menu() {
        char[][] matriz = new char[6][7];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                matriz[i][j] = '_';
            }
        }

        imprimirMatriz(matriz);
        JuegoEnAccion(matriz);

    }

    public void JuegoEnAccion(char[][] matriz) {
        JLabel color = new JLabel();
        boolean win = false;

        char jugador = 'O';
        color.setForeground(Color.BLUE);

        char maquina = 'X';
        color.setForeground(Color.red);

        int controndas = 0;
        int comodin = 0;
        int contadorComodin1 = 0;
        int contadorComodin2 = 0;
        int contadorComodin3 = 0;

        int contadorComodinM1 = 0;
        int contadorComodinM2 = 0;
        int contadorComodinM3 = 0;
        while (!win && controndas < 42) {

            int contadorcol = 5;
            int contadorcol2 = 5;
            int pos = 0;
            String[] resp = {"YES", "NO"};
            String[] Menucomodines = {"Muro de Ladrillo", "Pesa", "Bomba"};
            String Tipocomodin = "";

            boolean comodinUSE = false;
            if (controndas >= 9 && controndas % 5 == 0 && !win) {
                String SioNo = (String) JOptionPane.showInputDialog(null, "Turno del usuario \n\nDesea usar comodin?", "Conecta 4", JOptionPane.QUESTION_MESSAGE, null, resp, resp[0]);

                if (SioNo.equals("YES")) {
                    Tipocomodin = (String) JOptionPane.showInputDialog(null, "Ingrese cual desea usar", "COMODINES", JOptionPane.QUESTION_MESSAGE, null, Menucomodines, Menucomodines[0]);

                    if ((contadorComodin1 == 1 && Tipocomodin.equals("Muro de Ladrillo")) || (contadorComodin2 == 1 && Tipocomodin.equals("Pesa"))
                            || (contadorComodin3 == 1 && Tipocomodin.equals("Bomba"))) {
                        JOptionPane.showMessageDialog(null, "Comodin no disponible!!", "Comodines", JOptionPane.WARNING_MESSAGE);
                    } else {
                        comodinUSE = true;
                    }
                }

            }// fin del if que controla los comodines\

            while (true) {
                pos = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese posicion (0-6)"));
                if (pos >= 0 && pos < 7) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Posicion no valida, ingrese una correcta!", "Conecta 4", JOptionPane.WARNING_MESSAGE);
                }
            }

            while (matriz[contadorcol][pos] != '_') {
                matriz[contadorcol][pos] = matriz[contadorcol--][pos];
            }

            matriz[contadorcol][pos] = jugador;

            if (comodinUSE) {
                switch (Tipocomodin) {
                    case "Muro de Ladrillo":
                        comodines(matriz, 1, pos, contadorcol, jugador);
                        contadorComodin1++;

                        break;
                    case "Pesa":
                        contadorComodin2++;
                        comodines(matriz, 2, pos, contadorcol, jugador);
                        contadorComodin2++;

                        break;
                    case "Bomba":
                        contadorComodin3++;
                        comodines(matriz, 3, pos, contadorcol, jugador);
                        contadorComodin3++;

                        break;
                    default:
                        break;
                }
            }// fin del if ComodinUse
            imprimirMatriz(matriz);
            controndas++;

            if (verificarVictoria(matriz, jugador) == true) {
                JOptionPane.showMessageDialog(null, "**********HAS GANADO!!**********");
                win = true;
                break;
            }

            JOptionPane.showMessageDialog(null, "Turno de la maquina");
            int pos2 = rndm.nextInt(6);

            while (matriz[contadorcol2][pos2] != '_') {
                matriz[contadorcol2][pos2] = matriz[contadorcol2--][pos2];
                if (matriz[0][pos2] != '_' || matriz[0][pos2] < 0) {
                    pos2 = rndm.nextInt(6);
                }
            }
            matriz[contadorcol2][pos2] = maquina;

            if (controndas >= 9 && controndas % 5 == 0 && !win) {
                int probabilidadComodin = rndm.nextInt(100);
                boolean maquinaCOMODIN = false;
                if (probabilidadComodin <= 80) {
                    maquinaCOMODIN = true;
                } else {
                    break;
                }

                if (maquinaCOMODIN == true) {
                    int Tipodecomodin = rndm.nextInt(100);

                    if (Tipodecomodin <= 33 && contadorComodinM1 == 0) {
                        comodines(matriz, 1, pos2, contadorcol2, maquina);
                        JOptionPane.showMessageDialog(null, "La maquina ha usaodo el comodin del MURO", "Comodin", JOptionPane.INFORMATION_MESSAGE);
                        contadorComodinM1++;

                    } else if (Tipodecomodin > 33 && Tipodecomodin <= 66 && contadorComodinM2 == 0) {
                        comodines(matriz, 2, pos2, contadorcol2, maquina);
                        JOptionPane.showMessageDialog(null, "La maquina ha usaodo el comodin de la PESA", "Comodin", JOptionPane.INFORMATION_MESSAGE);
                        contadorComodinM2++;

                    } else if (Tipodecomodin > 66 && contadorComodinM3 == 0) {
                        comodines(matriz, 3, pos2, contadorcol2, maquina);
                        JOptionPane.showMessageDialog(null, "La maquina ha usaodo el comodin de la BOMBA", "Comodin", JOptionPane.INFORMATION_MESSAGE);
                        contadorComodinM3++;
                    } else {
                        break;
                    }
                } else {
                    break;
                }

            }// fin del if que conttrola cuando usar comodines'=

            imprimirMatriz(matriz);
            controndas++;

            if (verificarVictoria(matriz, maquina) == true) {
                JOptionPane.showMessageDialog(null, "HAS PERDIDO!! La maquina ha ganado");
                win = true;
                break;
            }

        }// fin del while que controla lel programa
        if (controndas
                == 41) {
            JOptionPane.showMessageDialog(null, "EMPATE!! Nadie ha ganado");
        }
    }

    public char[][] comodines(char[][] matriz, int tipo, int posicion, int contCOL, char jugador) {
        char[][] Nuevamatriz = new char[matriz.length][matriz[0].length];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                switch (tipo) {
                    case 1:
                        int comodinLad = contCOL;
                        for (int k = 0; k < matriz.length; k++) {
                            matriz[comodinLad - 1][posicion] = '#';
                        }
                        break;

                    case 2:
                        for (int k = contCOL; k < matriz.length; k++) {
                            for (int p = posicion; p < matriz[i].length; p++) {
                                if (posicion == matriz.length) {
                                    matriz[i][j] = jugador;
                                } else if (j == posicion) {
                                    matriz[i][j] = '_';
                                }
                            }
                        }
                        break;

                    case 3:
                        if (i >= 0 && i < matriz.length && posicion >= 0 && posicion < matriz[i].length) {
                            for (int row = Math.max(0, i - 1); row <= Math.min(matriz.length - 1, i + 1); row++) {
                                for (int col = Math.max(0, posicion - 1); col <= Math.min(matriz[row].length - 1, posicion + 1); col++) {
                                    //tuve que usar math ya que siempre se salia del length
                                    matriz[row][col] = '_';
                                }
                            }
                            matriz[i][posicion] = jugador;
                        }
                        break;

                }
            }
        }
        return Nuevamatriz;
    }

    public boolean verificarVictoria(char[][] matriz, char jugador) {
        // HORIZONTALES
        for (int i = 0; i < matriz.length - 3; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (matriz[i][j] == jugador && matriz[i + 1][j] == jugador && matriz[i + 2][j] == jugador && matriz[i + 3][j] == jugador) {
                    return true;
                }
            }
        }

        // VERTICALES
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length - 3; j++) {
                if (matriz[i][j] == jugador && matriz[i][j + 1] == jugador && matriz[i][j + 2] == jugador && matriz[i][j + 3] == jugador) {
                    return true;
                }
            }
        }

        // DIAGONALES
        for (int i = 0; i < matriz.length - 3; i++) {
            for (int j = 0; j < matriz[i].length - 3; j++) {
                if ((matriz[i][j] == jugador && matriz[i + 1][j + 1] == jugador && matriz[i + 2][j + 2] == jugador && matriz[i + 3][j + 3] == jugador)
                        || (matriz[i][j + 3] == jugador && matriz[i + 1][j + 2] == jugador && matriz[i + 2][j + 1] == jugador && matriz[i + 3][j] == jugador)) {
                    return true;
                }
            }
        }

        return false;
    }

    public void imprimirMatriz(char[][] matriz) {
        String acum = "";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                acum += "[" + matriz[i][j] + "]";
            }
            acum += "\n";
        }
        JOptionPane.showMessageDialog(null, "TABLERO ACTUAL \n\n" + acum);
    }// fin del imprimir 

}
